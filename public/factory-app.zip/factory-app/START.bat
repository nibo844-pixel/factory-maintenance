@echo off
title Factory Maintenance Server
echo.
echo   🏭 Factory Maintenance
echo   Μην κλείσεις αυτό το παράθυρο!
echo.
node server.js
pause
